"""Tools for aligning transcripts and speech signals
"""
