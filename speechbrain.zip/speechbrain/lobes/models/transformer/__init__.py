"""High level processing blocks.

This subpackage gathers higher level blocks, or "lobes".
The classes here may leverage the extended YAML syntax.
"""
