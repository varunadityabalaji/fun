""" Package containing various techniques of speech processing
"""
